/*
 * Author:	Jordan Twombly 
 * Class:� CSI 340-01
 * Assignment: Observer Pattern Implementation
 * Date�Assigned: 9/15/16
 * Due�Date: 9/20/16
 * 
 * Description:�Demonstrates the use of the Observer design pattern through the 
 * 				implementation of a Weather data service.
 * 
 * Certification�of�Authenticity:�
 * 		I certify�that�this�assignment�is�entirely�my�own�work.
 * 
 */

public class ForecastDisplay implements Observer, DisplayElement
{
	private double pressure, lastPressure;
	private Subject weatherData;
	
	public ForecastDisplay(Subject weatherData)
	{
		this.weatherData = weatherData;
		weatherData.addObserver(this);
	}
	
	//update code adapted from http://www.headfirstlabs.com/books/hfdp/
	public void update(double temp, double humidity, double pressure) 
	{
		lastPressure = this.pressure;
		this.pressure = pressure;
		
		display();
	}
	
	public void display()
	{
		System.out.print("Forecast: ");
		
		if (pressure > lastPressure) 
		{
			System.out.println("Improving weather on the way!");
		}
		else if (pressure == lastPressure) 
		{
			System.out.println("More of the same");
		}
		else if (pressure < lastPressure) 
		{
			System.out.println("Watch out for cooler, rainy weather");
		}
	}
}
