/*
 * Author:	Jordan Twombly 
 * Class:� CSI 340-01
 * Assignment: Observer Pattern Implementation
 * Date�Assigned: 9/15/16
 * Due�Date: 9/20/16
 * 
 * Description:�Demonstrates the use of the Observer design pattern through the 
 * 				implementation of a Weather data service.
 * 
 * Certification�of�Authenticity:�
 * 		I certify�that�this�assignment�is�entirely�my�own�work.
 * 
 */

public class CurrentConditionsDisplay implements Observer, DisplayElement
{
	private double temp, humidity;
	private Subject weatherData;
	
	public CurrentConditionsDisplay(Subject weatherData)
	{
		this.weatherData = weatherData;
		weatherData.addObserver(this);
	}
	
	public void update(double temp, double humidity, double pressure)
	{
		this.temp = temp;
		this.humidity = humidity;
		display();
	}
	
	public void display()
	{
		System.out.println("Current conditions: " + temp + "F degrees and " + humidity + "% humidity");
	}
}