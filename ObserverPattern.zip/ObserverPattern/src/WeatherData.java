/*
 * Author:	Jordan Twombly 
 * Class:� CSI 340-01
 * Assignment: Observer Pattern Implementation
 * Date�Assigned: 9/15/16
 * Due�Date: 9/20/16
 * 
 * Description:�Demonstrates the use of the Observer design pattern through the 
 * 				implementation of a Weather data service.
 * 
 * Certification�of�Authenticity:�
 * 		I certify�that�this�assignment�is�entirely�my�own�work.
 * 
 */

import java.util.ArrayList;

public class WeatherData implements Subject
{
	private ArrayList<Observer> observers;
	private double temp, humidity, pressure;
	
	public WeatherData()
	{
		observers = new ArrayList<Observer>();
	}
	
	public void addObserver(Observer obs)
	{
		observers.add(obs);
	}
	
	public void removeObserver(Observer obs)
	{
		int i = observers.indexOf(obs);;
		if (i >= 0)
		{
			observers.remove(i);
		}
	}
	
	public void notifyObservers()
	{
		for (int i = 0; i < observers.size(); i++)
		{
			Observer observer = (Observer)observers.get(i);
			observer.update(temp, humidity, pressure);
		}
	}
	
	public void measurementsChanged()
	{
		notifyObservers();
	}
	
	public void setMeasurements(double temp, double humidity, double pressure)
	{
		this.temp = temp;
		this.humidity = humidity;
		this.pressure = pressure;
		measurementsChanged();
	}
}
