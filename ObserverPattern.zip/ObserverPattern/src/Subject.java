/*
 * Author:	Jordan Twombly 
 * Class:� CSI 340-01
 * Assignment: Observer Pattern Implementation
 * Date�Assigned: 9/15/16
 * Due�Date: 9/20/16
 * 
 * Description:�Demonstrates the use of the Observer design pattern through the 
 * 				implementation of a Weather data service.
 * 
 * Certification�of�Authenticity:�
 * 		I certify�that�this�assignment�is�entirely�my�own�work.
 * 
 */

public interface Subject 
{
	public void addObserver(Observer obs);
	public void removeObserver(Observer obs);
	public void notifyObservers();
}
