/*
 * Author:	Jordan Twombly 
 * Class:� CSI 340-01
 * Assignment: Observer Pattern Implementation
 * Date�Assigned: 9/15/16
 * Due�Date: 9/20/16
 * 
 * Description:�Demonstrates the use of the Observer design pattern through the 
 * 				implementation of a Weather data service.
 * 
 * Certification�of�Authenticity:�
 * 		I certify�that�this�assignment�is�entirely�my�own�work.
 * 
 */

public class StatisticsDisplay implements Observer, DisplayElement
{
	private double temp, maxTemp = 0.0, minTemp = 200, tempTotal = 0.0;
	private int totalReadings;
	private Subject weatherData;
	
	public StatisticsDisplay(Subject weatherData)
	{
		this.weatherData = weatherData;
		weatherData.addObserver(this);
	}
	
	//update code adapted from http://www.headfirstlabs.com/books/hfdp/
	public void update(double temp, double humidity, double pressure) 
	{
		this.temp = temp;
		tempTotal += this.temp;
		totalReadings++;
		
		if (this.temp > maxTemp)
		{
			maxTemp = this.temp;
		}
		
		if (this.temp < minTemp)
		{
			minTemp = this.temp;
		}
		
		display();
	}
	
	public void display()
	{
		System.out.println("Avg/Max/Min temperature = " + (tempTotal / totalReadings) + "/" + maxTemp + "/" + minTemp);
	}
}
